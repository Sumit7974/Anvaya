/**
 * anvaya.com - Main Application Logic & Dynamic Marketplace Controller
 * Features: Fixed-Hour Booking (2h/4h/8h), ₹25 Platform Fee + ₹15 Insurance,
 * Dual Role Navigation, 12 Dynamic Specialists, Leaderboard & KYC Hub
 */

class AnvayaApp {
  constructor() {
    this.storageKeyUsers = 'anvaya_users_v4';
    this.storageKeyBookings = 'anvaya_bookings_v4';
    this.storageKeySession = 'anvaya_session_v4';
    this.storageKeyWorkers = 'anvaya_workers_v4';
    this.storageKeyTheme = 'anvaya_theme_pref';

    this.currentTheme = localStorage.getItem(this.storageKeyTheme) || 'light';
    this.currentUser = null;
    this.currentCategory = 'all';
    this.currentSort = 'rating';
    this.currentWorkerTab = 'dashboard';
    this.searchQuery = '';
    
    // Booking modal state
    this.selectedWorker = null;
    this.selectedHours = 4;
    this.isCustomHours = false;

    // Initialize data & UI
    this.seedInitialData();
    this.init();
  }

  /* =========================================================================
     1. INITIALIZATION & THEME ENGINE
     ========================================================================= */
  init() {
    this.applyTheme(this.currentTheme);
    
    // Load active session
    const savedSession = localStorage.getItem(this.storageKeySession);
    if (savedSession) {
      try {
        this.currentUser = JSON.parse(savedSession);
      } catch (e) {
        this.currentUser = null;
      }
    }

    this.renderMarketplace();
    this.renderLeaderboards();
    this.setupEventListeners();
  }

  setTheme(theme) {
    this.currentTheme = theme;
    localStorage.setItem(this.storageKeyTheme, theme);
    this.applyTheme(theme);
    this.showToast(`Theme changed to ${theme.toUpperCase()} mode`, 'info');
  }

  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const selectors = document.querySelectorAll('#theme-selector');
    selectors.forEach(sel => { sel.value = theme; });
  }

  /* =========================================================================
     2. DYNAMIC WORKERS SEED DATA (12 Verified Specialists)
     ========================================================================= */
  seedInitialData() {
    const initialWorkers = [
      {
        id: 1,
        name: 'Priya Sharma',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        title: 'Senior Full-Stack UI/React Specialist',
        category: 'tech',
        hourlyRate: 599,
        rating: 4.9,
        reviewsCount: 84,
        skills: ['React.js', 'Next.js', 'Node.js', 'API Integration', 'Tailwind'],
        bio: '8+ years building enterprise web apps and rapid MVP features. Available for 2h bug fixes to 8h full-day sprint development.',
        upiId: 'priya@okhdfcbank',
        isVerified: true
      },
      {
        id: 2,
        name: 'Vikram Singh',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        title: 'Lead UI/UX & Brand Identity Designer',
        category: 'design',
        hourlyRate: 499,
        rating: 4.9,
        reviewsCount: 62,
        skills: ['Figma', 'Web Design', 'Mobile UI', 'Design Systems', 'Logos'],
        bio: 'Crafts high-converting landing pages and modern mobile interfaces in fixed 2h to 8h focused design workshops.',
        upiId: 'vikram@okaxis',
        isVerified: true
      },
      {
        id: 3,
        name: 'Amit Patel',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        title: 'Certified Master Electrician & Tech Specialist',
        category: 'repairs',
        hourlyRate: 349,
        rating: 4.8,
        reviewsCount: 112,
        skills: ['Wiring & MCB', 'Inverter Setup', 'Appliance Repair', 'Lighting'],
        bio: 'Government licensed master electrician. Ready for 2h quick fixes, 4h home diagnostics, or 8h complete house wiring setups.',
        upiId: 'amit@okaxis',
        isVerified: true
      },
      {
        id: 4,
        name: 'Neha Kapoor',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        title: 'Commercial Photographer & 4K Video Editor',
        category: 'media',
        hourlyRate: 649,
        rating: 5.0,
        reviewsCount: 45,
        skills: ['Sony Alpha Kit', 'Premiere Pro', 'Color Grading', 'Product Shoots'],
        bio: 'Specialist in e-commerce product shoots and cinematic reels. Bring all lighting gear for 4h half-day or 8h full-day sessions.',
        upiId: 'neha@paytm',
        isVerified: true
      },
      {
        id: 5,
        name: 'Aarav Joshi',
        avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
        title: 'Flutter & Native Mobile App Engineer',
        category: 'tech',
        hourlyRate: 550,
        rating: 4.9,
        reviewsCount: 41,
        skills: ['Flutter', 'React Native', 'Firebase', 'State Management', 'Push Notifications'],
        bio: 'Cross-platform app specialist. Available for 2h UI debugging, 4h API integration, or 8h full store release preparation.',
        upiId: 'aarav@okicici',
        isVerified: true
      },
      {
        id: 6,
        name: 'Deepak Gupta',
        avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
        title: 'Smart Home Automation & AC Specialist',
        category: 'repairs',
        hourlyRate: 399,
        rating: 4.9,
        reviewsCount: 88,
        skills: ['Smart Switches', 'AC Servicing', 'CCTV Setup', 'WiFi Mesh'],
        bio: 'Certified smart home technician. Install smart lights, security cameras, or perform deep AC jet servicing in fixed 2h/4h slots.',
        upiId: 'deepak@paytm',
        isVerified: true
      },
      {
        id: 7,
        name: 'Ananya Roy',
        avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=150&auto=format&fit=crop&q=80',
        title: 'SEO Copywriter & Content Strategist',
        category: 'design',
        hourlyRate: 420,
        rating: 4.8,
        reviewsCount: 53,
        skills: ['SEO Articles', 'Landing Page Copy', 'Email Sequences', 'Brand Voice'],
        bio: 'Direct-response copywriter for D2C brands and tech startups. Get 3 high-ranking articles written in a dedicated 4h block.',
        upiId: 'ananya@okhdfcbank',
        isVerified: true
      },
      {
        id: 8,
        name: 'Rohan Deshmukh',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
        title: 'Full-Stack Python & Data Engineer',
        category: 'tech',
        hourlyRate: 699,
        rating: 4.9,
        reviewsCount: 58,
        skills: ['Python', 'FastAPI', 'PostgreSQL', 'Scraping', 'Docker'],
        bio: 'Backend architect specializing in REST APIs, web scrapers, and database performance tuning for fixed-hour jobs.',
        upiId: 'rohan@okicici',
        isVerified: true
      },
      {
        id: 9,
        name: 'Harish Verma',
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
        title: 'Sound Engineer & Podcast Producer',
        category: 'media',
        hourlyRate: 480,
        rating: 4.9,
        reviewsCount: 37,
        skills: ['Audio Cleanup', 'Podcast Editing', 'Logic Pro', 'Voiceover Master'],
        bio: 'Audio professional with broadcast-grade equipment. Available for 2h quick cleanups or 8h full episode studio production.',
        upiId: 'harish@okaxis',
        isVerified: true
      },
      {
        id: 10,
        name: 'Sunita Mehra',
        avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
        title: 'Deep Home Cleaning & Sanitization Lead',
        category: 'cleaning',
        hourlyRate: 299,
        rating: 4.8,
        reviewsCount: 94,
        skills: ['Deep Cleaning', 'Kitchen Degrease', 'Sofa Shampoo', 'Eco Chemicals'],
        bio: '5-star rated hygiene professional with industrial equipment. 4h deep clean or 8h complete move-in sanitization.',
        upiId: 'sunita@upi',
        isVerified: true
      },
      {
        id: 11,
        name: 'Kavita Iyer',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
        title: 'Maths & Coding Tutor (CBSE / ICSE / Python)',
        category: 'education',
        hourlyRate: 450,
        rating: 5.0,
        reviewsCount: 76,
        skills: ['Class 9-12 Maths', 'Python Basics', 'Competitive Exams', 'Doubt Clearing'],
        bio: 'IIT-alumnus educator available for intensive 2h doubt clearing or 4h complete chapter crash courses.',
        upiId: 'kavita@okhdfcbank',
        isVerified: true
      },
      {
        id: 12,
        name: 'Manish Rawat',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        title: 'Event Coordinator & Stage Tech Lead',
        category: 'events',
        hourlyRate: 350,
        rating: 4.7,
        reviewsCount: 39,
        skills: ['Stage Setup', 'Guest Logistics', 'Audio & Mic Tech', 'Vendor Escort'],
        bio: 'Energetic event professional for weddings, tech meetups, and corporate exhibitions. Available for 4h or 8h fixed shifts.',
        upiId: 'manish@okaxis',
        isVerified: true
      }
    ];

    localStorage.setItem(this.storageKeyWorkers, JSON.stringify(initialWorkers));

    if (!localStorage.getItem(this.storageKeyBookings)) {
      const initialBookings = [
        {
          id: 'ANV-2026-89421',
          workerId: 1,
          workerName: 'Priya Sharma',
          workerTitle: 'Senior Full-Stack UI/React Specialist',
          workerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          clientUsername: 'rahul_client',
          clientName: 'Rahul Verma',
          hours: 4,
          rate: 599,
          baseSubtotal: 2396,
          clientPlatformFee: 25,
          clientInsuranceFee: 15,
          total: 2436,
          workerPlatformFee: 25,
          workerInsuranceFee: 15,
          workerNetPayout: 2356,
          date: '2026-08-27',
          time: '02:00 PM',
          notes: 'Build interactive chart dashboard and connect REST endpoints.',
          status: 'Confirmed',
          startOtp: '7492',
          insuranceCover: '₹25,000 Active',
          createdAt: new Date().toISOString()
        }
      ];
      localStorage.setItem(this.storageKeyBookings, JSON.stringify(initialBookings));
    }
  }

  /* =========================================================================
     3. DYNAMIC MARKETPLACE RENDERING & SEARCH
     ========================================================================= */
  renderMarketplace() {
    const grid = document.getElementById('worker-grid');
    if (!grid) return;

    const workers = JSON.parse(localStorage.getItem(this.storageKeyWorkers)) || [];
    let filtered = workers;

    // Filter by Category
    if (this.currentCategory !== 'all') {
      filtered = filtered.filter(w => w.category === this.currentCategory);
    }

    // Filter by Search Term
    if (this.searchQuery.trim()) {
      const q = this.searchQuery.toLowerCase();
      filtered = filtered.filter(w => 
        w.name.toLowerCase().includes(q) ||
        w.title.toLowerCase().includes(q) ||
        w.bio.toLowerCase().includes(q) ||
        w.skills.some(s => s.toLowerCase().includes(q))
      );
    }

    // Sorting
    if (this.currentSort === 'price-low') {
      filtered.sort((a, b) => a.hourlyRate - b.hourlyRate);
    } else if (this.currentSort === 'price-high') {
      filtered.sort((a, b) => b.hourlyRate - a.hourlyRate);
    } else {
      filtered.sort((a, b) => b.rating - a.rating || b.reviewsCount - a.reviewsCount);
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div style="grid-column:1/-1; text-align:center; padding:50px 20px; background:var(--bg-surface); border-radius:var(--radius-lg); border:1px dashed var(--border-color);">
          <div style="font-size:2.5rem; margin-bottom:10px;">🔍</div>
          <h3>No Specialists Found</h3>
          <p style="color:var(--text-muted);">Try a different search keyword or category filter.</p>
          <button class="btn btn-outline" onclick="hiremeApp.filterByCategory('all')" style="margin-top:14px;">Reset Filters</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(w => `
      <div class="worker-card-item">
        <div class="worker-card-header">
          <div class="card-avatar-wrap">
            <img src="${w.avatar}" alt="${w.name}" class="card-avatar">
            <span class="card-verified">✓</span>
          </div>
          <div class="card-details">
            <h3 class="card-name">${w.name}</h3>
            <p class="card-role-title">${w.title}</p>
            <div class="card-rating-row">
              <span class="card-rating-num">★ ${w.rating}</span>
              <span class="card-gigs-count">(${w.reviewsCount} fixed gigs)</span>
            </div>
          </div>
        </div>

        <div class="worker-card-body">
          <p class="card-bio">${w.bio}</p>
          <div class="card-skills-tags">
            ${(w.skills || []).map(s => `<span class="skill-tag">${s}</span>`).join('')}
          </div>
          <div class="card-fixed-pricing">
            <div class="slot-item">
              <span class="slot-hours">2 Hours</span>
              <span class="slot-price">₹${(w.hourlyRate * 2).toLocaleString('en-IN')}</span>
            </div>
            <div class="slot-item">
              <span class="slot-hours">4 Hours</span>
              <span class="slot-price">₹${(w.hourlyRate * 4).toLocaleString('en-IN')}</span>
            </div>
            <div class="slot-item">
              <span class="slot-hours">8 Hours</span>
              <span class="slot-price">₹${(w.hourlyRate * 8).toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        <div class="worker-card-footer">
          <div>
            <span class="card-rate-label">Hourly Rate</span>
            <span class="card-rate-val">₹${w.hourlyRate}<small style="font-size:0.75rem; color:var(--text-muted); font-weight:normal;">/hr</small></span>
          </div>
          <button class="btn btn-primary" onclick="hiremeApp.openBookingModal(${w.id})">
            Hire Fixed Hours →
          </button>
        </div>
      </div>
    `).join('');
  }

  filterByCategory(cat) {
    this.currentCategory = cat;
    document.querySelectorAll('.cat-pill').forEach(pill => {
      pill.classList.toggle('active', pill.dataset.category === cat);
    });
    this.renderMarketplace();
  }

  handleSearchInput(val) {
    this.searchQuery = val;
    this.renderMarketplace();
  }

  changeSort(sort) {
    this.currentSort = sort;
    this.renderMarketplace();
  }

  /* =========================================================================
     4. FIXED-HOURS BOOKING ENGINE & DYNAMIC CALCULATOR
     ========================================================================= */
  openBookingModal(workerId) {
    const workers = JSON.parse(localStorage.getItem(this.storageKeyWorkers)) || [];
    this.selectedWorker = workers.find(w => w.id === workerId);
    if (!this.selectedWorker) return;

    this.selectedHours = 4;
    this.isCustomHours = false;

    // Populate worker summary in modal
    const summary = document.getElementById('booking-worker-summary');
    if (summary) {
      summary.innerHTML = `
        <img src="${this.selectedWorker.avatar}" alt="${this.selectedWorker.name}" class="booking-worker-img">
        <div class="booking-worker-meta">
          <h4>${this.selectedWorker.name}</h4>
          <p>${this.selectedWorker.title}</p>
          <span style="font-size:0.75rem; color:var(--color-accent); font-weight:700;">★ ${this.selectedWorker.rating} • Verified Specialist</span>
        </div>
        <div class="booking-worker-rate">
          <span style="font-size:0.7rem; color:var(--text-muted); display:block;">Rate</span>
          <strong>₹${this.selectedWorker.hourlyRate}/hr</strong>
        </div>
      `;
    }

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dateInput = document.getElementById('booking-date');
    if (dateInput) dateInput.value = tomorrow.toISOString().split('T')[0];

    this.updateBookingCalculations();
    this.openModal('booking-modal');
  }

  setBookingDuration(hours) {
    this.selectedHours = parseInt(hours);
    this.isCustomHours = false;
    const chk = document.getElementById('custom-hours-check');
    if (chk) chk.checked = false;
    const ctrl = document.getElementById('custom-hours-control');
    if (ctrl) ctrl.style.display = 'none';

    document.querySelectorAll('.duration-card').forEach(card => {
      card.classList.toggle('selected', parseInt(card.dataset.hours) === hours);
    });

    this.updateBookingCalculations();
  }

  toggleCustomHours(isChecked) {
    this.isCustomHours = isChecked;
    const ctrl = document.getElementById('custom-hours-control');
    if (ctrl) ctrl.style.display = isChecked ? 'flex' : 'none';

    if (isChecked) {
      document.querySelectorAll('.duration-card').forEach(c => c.classList.remove('selected'));
      this.selectedHours = parseInt(document.getElementById('custom-hours-input').value) || 3;
    } else {
      this.setBookingDuration(4);
    }
    this.updateBookingCalculations();
  }

  setCustomHours(val) {
    this.selectedHours = Math.max(1, Math.min(24, parseInt(val) || 1));
    this.updateBookingCalculations();
  }

  updateBookingCalculations() {
    if (!this.selectedWorker) return;

    const rate = this.selectedWorker.hourlyRate;
    const hours = this.selectedHours;
    const baseSubtotal = rate * hours;
    const platformFee = 25;
    const insuranceFee = 15;
    const totalClientPayable = baseSubtotal + platformFee + insuranceFee;
    const workerNetPayout = baseSubtotal - (platformFee + insuranceFee);

    const el2h = document.getElementById('calc-2h-price');
    const el4h = document.getElementById('calc-4h-price');
    const el8h = document.getElementById('calc-8h-price');
    if (el2h) el2h.textContent = `₹${(rate * 2).toLocaleString('en-IN')}`;
    if (el4h) el4h.textContent = `₹${(rate * 4).toLocaleString('en-IN')}`;
    if (el8h) el8h.textContent = `₹${(rate * 8).toLocaleString('en-IN')}`;

    const lbl = document.getElementById('calc-breakdown-label');
    const base = document.getElementById('calc-base-subtotal');
    const total = document.getElementById('calc-total-amount');
    const preview = document.getElementById('calc-worker-payout-preview');

    if (lbl) lbl.textContent = `Base Service Cost (₹${rate} × ${hours} Hours):`;
    if (base) base.textContent = `₹${baseSubtotal.toLocaleString('en-IN')}`;
    if (total) total.textContent = `₹${totalClientPayable.toLocaleString('en-IN')}`;
    if (preview) {
      preview.textContent = `Worker Net Payout: ₹${workerNetPayout.toLocaleString('en-IN')} (Gross ₹${baseSubtotal.toLocaleString('en-IN')} - ₹25 platform fee - ₹15 on-job insurance)`;
    }
  }

  handleBookingSubmit(event) {
    event.preventDefault();
    if (!this.selectedWorker) return;

    const date = document.getElementById('booking-date').value;
    const time = document.getElementById('booking-time').value;
    const notes = document.getElementById('booking-notes').value || 'Standard fixed-hours assistance';
    const rate = this.selectedWorker.hourlyRate;
    const hours = this.selectedHours;
    const baseSubtotal = rate * hours;
    const startOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const bookingId = `ANV-2026-${Math.floor(100000 + Math.random() * 900000)}`;

    const newBooking = {
      id: bookingId,
      workerId: this.selectedWorker.id,
      workerName: this.selectedWorker.name,
      workerTitle: this.selectedWorker.title,
      workerAvatar: this.selectedWorker.avatar,
      clientUsername: 'client_user',
      clientName: 'Rahul Verma',
      hours: hours,
      rate: rate,
      baseSubtotal: baseSubtotal,
      clientPlatformFee: 25,
      clientInsuranceFee: 15,
      total: baseSubtotal + 40,
      workerPlatformFee: 25,
      workerInsuranceFee: 15,
      workerNetPayout: baseSubtotal - 40,
      date: date,
      time: time,
      notes: notes,
      status: 'Confirmed',
      startOtp: startOtp,
      insuranceCover: '₹25,000 Active',
      createdAt: new Date().toISOString()
    };

    const bookings = JSON.parse(localStorage.getItem(this.storageKeyBookings)) || [];
    bookings.unshift(newBooking);
    localStorage.setItem(this.storageKeyBookings, JSON.stringify(bookings));

    this.closeAllModals();
    this.showToast(`🎉 Booking Confirmed! Start OTP: ${startOtp}. Notification dispatched!`, 'success');
    this.openClientDashboard();
  }

  openClientDashboard() {
    const header = document.getElementById('client-dashboard-header');
    const stats = document.getElementById('client-dashboard-stats');
    const list = document.getElementById('client-bookings-list');
    const badge = document.getElementById('client-badge-count');

    if (!header || !list) return;

    header.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div>
          <h3>Client Workspace — My Scheduled Gigs</h3>
          <p style="font-size:0.85rem; color:var(--text-muted);">Manage your scheduled fixed-hour slots, Start OTPs, and escrow protection.</p>
        </div>
        <span class="pro-badge-verified">🛡️ ₹25k DAMAGE COVER ACTIVE</span>
      </div>
    `;

    const bookings = JSON.parse(localStorage.getItem(this.storageKeyBookings)) || [];
    if (badge) badge.textContent = `${bookings.length} Gigs`;

    if (stats) {
      stats.innerHTML = `
        <div class="pro-stat-box">
          <div class="pro-stat-val">${bookings.length}</div>
          <div class="pro-stat-lbl">Active Gigs</div>
        </div>
        <div class="pro-stat-box">
          <div class="pro-stat-val">${bookings.reduce((sum, b) => sum + b.hours, 0)} hrs</div>
          <div class="pro-stat-lbl">Total Fixed Hours</div>
        </div>
        <div class="pro-stat-box highlight">
          <div class="pro-stat-val">₹25,000</div>
          <div class="pro-stat-lbl">Insurance Active</div>
        </div>
      `;
    }

    list.innerHTML = bookings.map(b => `
      <div class="pro-job-card">
        <div class="pro-job-meta">
          <div style="display:flex; align-items:center; gap:8px;">
            <span style="font-size:0.75rem; font-weight:800; background:#fef3c7; color:#92400e; padding:2px 8px; border-radius:4px;">${b.id}</span>
            <span style="font-size:0.75rem; font-weight:700; color:var(--color-accent);">● ${b.status}</span>
          </div>
          <h4 style="margin-top:6px;">${b.hours} Hours with ${b.workerName}</h4>
          <p>📅 ${b.date} at ${b.time} • ₹${b.rate}/hr</p>
          <div style="margin-top:8px; background:var(--color-primary-light); padding:8px 12px; border-radius:6px; display:inline-block;">
            <span style="font-size:0.85rem; color:var(--color-primary); font-weight:800;">
              🔑 Start OTP: <strong>${b.startOtp}</strong>
            </span>
            <span style="font-size:0.75rem; color:var(--text-muted); margin-left:6px;">(Share with specialist on arrival)</span>
          </div>
        </div>
        <div class="pro-job-actions">
          <div class="pro-payout-display" style="color:var(--color-primary);">₹${b.total.toLocaleString('en-IN')}</div>
          <div style="font-size:0.72rem; color:var(--text-muted);">Includes Flat ₹25 Fee + ₹15 Insurance</div>
        </div>
      </div>
    `).join('');

    this.openModal('client-dashboard-modal');
  }

  /* =========================================================================
     5. WORKER COMMAND CENTER CONTROLLER
     ========================================================================= */
  setWorkerTab(tabId) {
    this.currentWorkerTab = tabId;
    document.querySelectorAll('.w-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabId);
    });
    document.querySelectorAll('.worker-tab-content').forEach(panel => {
      panel.style.display = 'none';
    });
    const active = document.getElementById(`w-tab-${tabId}`);
    if (active) active.style.display = 'block';
  }

  toggleWorkerAvailability(isOnline) {
    const statusText = document.getElementById('worker-avail-status-text');
    if (!statusText) return;
    if (isOnline) {
      statusText.className = 'status-online';
      statusText.textContent = '🟢 Available for Bookings';
      this.showToast('You are now ONLINE and accepting new fixed-hour jobs', 'success');
    } else {
      statusText.className = 'status-offline';
      statusText.style.color = '#ef4444';
      statusText.textContent = '🔴 Offline / Busy';
      this.showToast('You are now OFFLINE. New requests paused.', 'info');
    }
  }

  saveWorkerProfile(event) {
    event.preventDefault();
    const fullname = document.getElementById('pro-edit-fullname').value;
    const title = document.getElementById('pro-edit-title').value;
    const category = document.getElementById('pro-edit-category').value;
    const rate = parseInt(document.getElementById('pro-edit-rate').value);
    const upi = document.getElementById('pro-edit-upi').value;
    const skills = document.getElementById('pro-edit-skills').value.split(',').map(s => s.trim());
    const bio = document.getElementById('pro-edit-bio').value;

    const workers = JSON.parse(localStorage.getItem(this.storageKeyWorkers)) || [];
    if (workers.length > 0) {
      workers[0].name = fullname;
      workers[0].title = title;
      workers[0].category = category;
      workers[0].hourlyRate = rate;
      workers[0].upiId = upi;
      workers[0].skills = skills;
      workers[0].bio = bio;
      localStorage.setItem(this.storageKeyWorkers, JSON.stringify(workers));
    }

    this.showToast('Profile & hourly rates updated successfully!', 'success');
    this.renderMarketplace();
    this.renderLeaderboards();
  }

  markJobComplete(jobId) {
    const bookings = JSON.parse(localStorage.getItem(this.storageKeyBookings)) || [];
    const job = bookings.find(b => b.id === jobId);
    if (job) {
      job.status = 'Completed';
      localStorage.setItem(this.storageKeyBookings, JSON.stringify(bookings));
      this.showToast(`🎉 Gig ${jobId} Completed! ₹${job.workerNetPayout} credited to your UPI.`, 'success');
      this.renderWorkerIncomingJobs(1);
    }
  }

  renderWorkerIncomingJobs(workerId) {
    const list = document.getElementById('pro-incoming-jobs-list');
    const countBadge = document.getElementById('w-job-count');
    if (!list) return;

    const bookings = JSON.parse(localStorage.getItem(this.storageKeyBookings)) || [];
    if (countBadge) countBadge.textContent = `${bookings.length} Gigs`;

    list.innerHTML = bookings.map(job => `
      <div class="pro-job-card">
        <div class="pro-job-meta">
          <div style="display:flex; align-items:center; gap:8px;">
            <span style="font-size:0.75rem; font-weight:800; background:#fef3c7; color:#92400e; padding:2px 8px; border-radius:4px;">${job.id}</span>
            <span style="font-size:0.75rem; font-weight:700; color:var(--color-accent);">● ${job.status.toUpperCase()}</span>
          </div>
          <h4 style="margin-top:6px;">${job.hours} Hours Fixed Gig with ${job.clientName}</h4>
          <p>📅 <strong>${job.date}</strong> at <strong>${job.time}</strong> • 📍 Client Premises</p>
          <div class="job-notes">📝 <em>"${job.notes}"</em></div>
          <div style="margin-top:8px; font-size:0.78rem; color:var(--text-muted);">
            🔑 <strong>Start OTP required from client upon arrival:</strong> <span style="background:var(--color-primary-light); color:var(--color-primary); font-weight:800; padding:2px 6px; border-radius:4px;">${job.startOtp}</span>
          </div>
        </div>

        <div class="pro-job-actions">
          <div class="pro-payout-display">₹${(job.workerNetPayout || (job.baseSubtotal - 40)).toLocaleString('en-IN')}</div>
          <div style="font-size:0.72rem; color:var(--text-muted);">Guaranteed Net Payout (₹25 Fee + ₹15 Insurance Deducted)</div>
          ${job.status === 'Confirmed' ? `
            <button class="btn btn-primary" onclick="hiremeApp.markJobComplete('${job.id}')">
              Mark Completed & Release Escrow →
            </button>
          ` : `
            <span style="font-size:0.85rem; font-weight:700; color:var(--color-accent);">✓ Payout Credited to UPI</span>
          `}
        </div>
      </div>
    `).join('');
  }

  /* =========================================================================
     6. LEADERBOARD RENDERING
     ========================================================================= */
  renderLeaderboards() {
    const leaderboardData = [
      {
        rank: 1,
        name: 'Priya Sharma',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        category: 'Tech & Coding',
        hours: 84,
        rating: '5.0 ★',
        earnings: '₹48,920',
        badge: '🏆 GOLD PRO #1'
      },
      {
        rank: 2,
        name: 'Vikram Singh',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        category: 'UI/UX Design',
        hours: 62,
        rating: '4.9 ★',
        earnings: '₹38,400',
        badge: '🥈 SILVER PRO #2'
      },
      {
        rank: 3,
        name: 'Neha Kapoor',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        category: 'Photography & Media',
        hours: 54,
        rating: '5.0 ★',
        earnings: '₹33,748',
        badge: '🥉 BRONZE PRO #3'
      },
      {
        rank: 4,
        name: 'Amit Patel',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        category: 'Master Electrician',
        hours: 85,
        rating: '4.8 ★',
        earnings: '₹29,665',
        badge: 'TOP FIXER'
      },
      {
        rank: 5,
        name: 'Aarav Joshi',
        avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
        category: 'Mobile Apps',
        hours: 48,
        rating: '4.9 ★',
        earnings: '₹26,400',
        badge: 'APP PRO'
      },
      {
        rank: 6,
        name: 'Rohan Deshmukh',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
        category: 'Python Backend',
        hours: 42,
        rating: '4.9 ★',
        earnings: '₹28,550',
        badge: 'CODE LEADER'
      }
    ];

    const podiumHtml = leaderboardData.slice(0, 3).map(p => `
      <div class="podium-card ${p.rank === 1 ? 'gold' : ''}">
        <span class="podium-rank-badge" style="${p.rank === 2 ? 'background:#94a3b8;' : p.rank === 3 ? 'background:#b45309;' : ''}">
          ${p.badge}
        </span>
        <img src="${p.avatar}" alt="${p.name}" class="podium-avatar">
        <h4 class="podium-name">${p.name}</h4>
        <span class="podium-category">${p.category}</span>
        <div class="podium-amount">${p.earnings}</div>
        <span class="podium-hours">${p.hours} Fixed Hours Delivered</span>
      </div>
    `).join('');

    const tableHtml = leaderboardData.map(p => `
      <tr>
        <td><strong>#${p.rank}</strong></td>
        <td>
          <div class="pro-table-user">
            <img src="${p.avatar}" alt="${p.name}" class="table-avatar">
            <div>
              <strong>${p.name}</strong>
              <div style="font-size:0.72rem; color:var(--text-muted);">${p.badge}</div>
            </div>
          </div>
        </td>
        <td>${p.category}</td>
        <td><strong>${p.hours} hrs</strong></td>
        <td style="color:var(--color-warning); font-weight:700;">${p.rating}</td>
        <td style="color:var(--color-accent); font-weight:800; font-family:var(--font-heading);">${p.earnings}</td>
        <td><span class="pro-badge-verified">✓ DigiLocker Verified</span></td>
        <td><a href="client.html" class="btn btn-outline" style="padding:4px 10px; font-size:0.78rem;">Book Fixed Hours</a></td>
      </tr>
    `).join('');

    const standalonePodium = document.getElementById('standalone-leaderboard-podium');
    const standaloneTable = document.getElementById('standalone-leaderboard-table-body');
    if (standalonePodium) standalonePodium.innerHTML = podiumHtml;
    if (standaloneTable) standaloneTable.innerHTML = tableHtml;

    this.renderWorkerIncomingJobs(1);
  }

  /* =========================================================================
     7. UI HELPERS & MODALS
     ========================================================================= */
  openModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) {
      el.classList.add('active');
      el.setAttribute('aria-hidden', 'false');
    }
  }

  closeAllModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => {
      m.classList.remove('active');
      m.setAttribute('aria-hidden', 'true');
    });
  }

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(20px)';
      setTimeout(() => toast.remove(), 300);
    }, 3800);
  }

  setupEventListeners() {
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) this.closeAllModals();
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeAllModals();
    });
  }
}

// Global Instance
const hiremeApp = new AnvayaApp();
